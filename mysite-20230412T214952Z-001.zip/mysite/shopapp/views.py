from timeit import default_timer
from django.http import HttpResponse, HttpRequest
from django.shortcuts import render
from django.contrib.auth.models import Group
from .models import Product, Order
from .forms import ProductForm

# Create your views here.
def shop_index(request: HttpRequest):
    products = [
        ('Laptop', 1000),
        ('Desktop', 2000),
        ('Smartphone', 500),
    ]
    context = {
        "time_running": default_timer(),
        "products": products,
    }
    return render(request, 'shopapp/shop-index.html', context=context)

def groups_list(request: HttpRequest):
    context = {
        "groups": Group.objects.prefetches_related('permissons').all(),
    }
    return render(request,'shopapp/groups-list.html', context=context)

def products_list(request: HttpRequest):
    context = {
        'products': Product.objects.all(),
    }
    return render(request,'shopapp/products-list.html', context=context)

def create_product(request: HttpRequest) -> HttpResponse:
    # form = ProductForm()
    # context = {
    #     "form": form,
    # }
    return render(request, 'shopapp/create-product.html')#, context=context)
def orders_list(request: HttpRequest):
    context = {
        "orders": Order.objects.select_related("user").all(),#prefetches_related('products').all(),
    }
    return render(request,'shopapp/orders-list.html', context=context)